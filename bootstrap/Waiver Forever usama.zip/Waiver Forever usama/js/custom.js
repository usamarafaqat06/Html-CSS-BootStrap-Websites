$(document).ready(function () {
  $(".navbar-toggler").click(function () {
    $("header").toggleClass("header-bottom-bg");
  });
});
$(document).ready(function () {
  $(window).scroll(function () {
    var scrollPosition = $(window).scrollTop();

    if (scrollPosition > 50) {
      $("header").css("background-color", "#000");
      // $(".header-top").css("display", "none");
    } else {
      $("header").css("background-color", "transparent");
      // $(".header-top").css("display", "block");
    }
  });
});
